<?php
if ( isset( $_POST['search'] ) ) {
    $pixa = curl_init();
    $search=$_POST['search'];
    $type_of=$_POST['type_of'];
    if($_POST['type_of']=="image")
    curl_setopt($pixa,CURLOPT_URL,"https://pixabay.com/api/?key=22703534-3c0216d0fe4f3e98006f51588&q=$search&image_type=photo&pretty=true");
    else if($_POST['type_of']=="video"){
    curl_setopt($pixa,CURLOPT_URL,"https://pixabay.com/api/videos/?key=22703534-3c0216d0fe4f3e98006f51588&q=$search");
    }
    curl_setopt($pixa,CURLOPT_RETURNTRANSFER,true);
    $result=curl_exec($pixa);
    curl_close($pixa); 
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pixabay Image Finder</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>
    <div class="container mt-5">
    <form class="text-center" action="" method="post">
    <div >
    <input class="form-control"  type="text" name ="search" value="<?php if (isset($_POST['search'])) echo $_POST['search']; ?>" />
    <input id="images" <?php if (isset($_POST['type_of']) && $_POST['type_of']=="image") echo("checked"); ?>  type="radio" name ="type_of" value="image" />
    <label for="images">Images</label><br>
    <input id="videos" <?php if (isset($_POST['type_of']) && $_POST['type_of']=="video") echo("checked"); ?>  type="radio" name ="type_of" value="video" />
    <label for="videos">Videos</label><br>
    </div>    
    <input type="submit" class="btn btn-info mt-2" />
    </form>
    </div>
    

	<section class="row m-2 p-2" >
            <?php
                if ( isset( $_POST['search'] ) ) {
                    if(empty($result)){
                        echo("No result found");
                    }
                    else{
                    if($_POST['type_of']=="image"){
                    $arr = json_decode($result, true);
                    $arr= $arr['hits'];
                    foreach($arr as $image){
            ?>
                            <div class="col-lg-3">
                            <img src="<?php echo($image['largeImageURL']);?>" height="200px" width="400px">
                            </div>
            <?php
                    }
                }
                else{
                    $arr = json_decode($result, true);
                    $arr= $arr['hits'];
                    foreach($arr as $video){
            ?>
                            <div class="col-lg-3">
                            <video src="<?php echo $video['videos']['small']['url'];?>" width="400px" height="200px" controls></video>
                            </div>
            <?php
                    }
                }
            }
            }
            ?>
        </section>
</body>
</html>